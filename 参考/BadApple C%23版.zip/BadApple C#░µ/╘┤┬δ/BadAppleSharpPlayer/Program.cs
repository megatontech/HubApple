﻿using System;
using System.Text;
using System.IO;
using System.IO.Compression;
using System.Timers;
using NAudio.Wave;

namespace BadAppleSharpPlayer
{
    class Program
    {
        private static StreamReader reader;
        static void Main(string[] args)
        {
            //打开压缩文本流
            FileStream fileStream = new FileStream("badapple.dat", FileMode.Open, FileAccess.Read);
            GZipStream compressionStream = new GZipStream(fileStream, CompressionMode.Decompress);
            reader = new StreamReader(compressionStream);

            //初始化控制台参数
            Console.Title = "BadAppleSharp 0.1";
            Console.WindowWidth = 80;
            Console.WindowHeight = 31;

            //调用播放器播放背景音乐
            WaveStream mp3Reader = new Mp3FileReader(@"BadApple.mp3");
            WaveStream pcmStreamer = WaveFormatConversionStream.CreatePcmStream(mp3Reader);
            WaveStream blockAlignedStream = new BlockAlignReductionStream(pcmStreamer);
            WaveOut waveOut = new WaveOut(WaveCallbackInfo.FunctionCallback());
            waveOut.Init(blockAlignedStream);
            waveOut.Play();

            //初始化定时器
            Timer timer = new Timer(55);
            timer.Elapsed+=new ElapsedEventHandler(Render);
            timer.Enabled = true;

            Console.ReadKey();
            waveOut.Dispose();
            blockAlignedStream.Dispose();
            pcmStreamer.Dispose();
            mp3Reader.Dispose();
        }

        //渲染一帧
        public static void Render(Object sender,ElapsedEventArgs e)
        {
            {
                Console.Clear();
                StringBuilder data=new StringBuilder(2500);
                for (int i = 0; i < 30; i++)
                {
                    data.Append(reader.ReadLine());
                }
                Console.Write(data.ToString());
            }

        }
    }
}
