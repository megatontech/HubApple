﻿using System;
using System.Drawing;
using System.IO;
using System.IO.Compression;

namespace BadAppleSharpEncoder
{
    class Program
    {
        static void Main(string[] args)
        {
            //获取in目录下所有文件 未作异常处理
            string[] path = Directory.GetFileSystemEntries("in");
            
            //保存为Gzip压缩的文本流
            FileStream fileStream = new FileStream("badapple.dat", FileMode.Create, FileAccess.Write);
            GZipStream compressionStream = new GZipStream(fileStream, CompressionMode.Compress);
            StreamWriter sw = new StreamWriter(compressionStream);

            //遍历每个像素点
            for (int x=0;x<path.Length;x++)
            {
                //Console.WriteLine(path[x]);
                Bitmap bitmap = new Bitmap(path[x]);

                for (int i = 0; i < bitmap.Height; i++)
                {
                    for (int j = 0; j < bitmap.Width; j++)
                    {
                        Color color = bitmap.GetPixel(j, i);
                        if (color.R > 200)
                        {
                            //Console.Write("1");
                            sw.Write(" ");
                        }
                        else
                        {
                            //Console.Write("0");
                            sw.Write("#");
                        }
                    }
                    //Console.WriteLine();
                    sw.WriteLine();
                    Console.Clear();
                    Console.WriteLine("{0} of {1} completed! ",x,path.Length);
                }
                bitmap.Dispose();
            }
            sw.Dispose();
        }
       
    }
}
